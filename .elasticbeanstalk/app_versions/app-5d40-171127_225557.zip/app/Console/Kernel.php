<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();
        // Da ka Event
        $schedule->call(function(){
            $url = 'http://jira.multiverseinc.com/PunchEvent';
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url);
            if ($res->voiceUrl==''){
                $res = $client->request('GET',$url);
            }
        })->wednesdays()->at('22:58')->timezone('Asia/Shanghai');
        $schedule->call(function(){
            $url = 'http://jira.multiverseinc.com/PunchEvent';
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url);
            if ($res->voiceUrl==''){
                $res = $client->request('GET',$url);
            }
        })->wednesdays()->at('9:13')->timezone('Asia/Shanghai');
        // Check sprint progress.
        $schedule->call(function(){
            $url = 'http://jira.multiverseinc.com/amChecked';
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url);
            if ($res->voiceUrl==''){
                $res = $client->request('GET',$url);
            }
        })->wednesdays()->at('10:00')->timezone('Asia/Shanghai');;
        // Verify completed tasks
        $schedule->call(function(){
            $url = 'http://jira.multiverseinc.com/doneIssueChecked';
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url);
            if ($res->voiceUrl==''){
                $res = $client->request('GET',$url);
            }
        })->wednesdays()->at('17:30')->timezone('Asia/Shanghai');;
        // volunteer for unassigned task.
        $schedule->call(function(){
            $url = 'http://jira.multiverseinc.com/todoChecked';
            $client = new \GuzzleHttp\Client();
            $res = $client->request('GET',$url);
            if ($res->voiceUrl==''){
                $res = $client->request('GET',$url);
            }
        })->weekdays()->everyFiveMinutes();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
