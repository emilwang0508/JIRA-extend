<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'brezzhnev/atlassian-connect-core' => 
  array (
    'providers' => 
    array (
      0 => 'AtlassianConnectCore\\ServiceProvider',
    ),
    'aliases' => 
    array (
      'Descriptor' => 'AtlassianConnectCore\\Facades\\Descriptor',
    ),
  ),
  'pusher/pusher-http-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pusher\\Laravel\\PusherServiceProvider',
    ),
    'aliases' => 
    array (
      'Pusher' => 'Pusher\\Laravel\\Facades\\Pusher',
    ),
  ),
);